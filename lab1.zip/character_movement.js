function moveLastThreeToFront(str) {
    if (str.length < 3) {
        return "String must be at least 3 characters long.";
    }

    let lastThree = str.slice(-3);
    let rest = str.slice(0, -3);
    return lastThree + rest;
}

console.log(moveLastThreeToFront("abcdef"));
console.log(moveLastThreeToFront("JavaScript"));
console.log(moveLastThreeToFront("cat"));
console.log(moveLastThreeToFront("cato"));
console.log(moveLastThreeToFront("hi"));
