const readline = require("readline");

// function to capitalize first letter of each word
function capitalizeFirstLetter(str) {
    return str
        .split(" ")
        .map(word =>
            word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
        )
        .join(" ");
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// ask user for input
rl.question("Please enter a string, the first letter of each word will be capitalized: ", function(answer) {
    console.log("Capitalized:", capitalizeFirstLetter(answer));
    rl.close();
});
