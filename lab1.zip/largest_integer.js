function findLargestInteger(a, b, c) {
    let largest;

    if (a >= b && a >= c) {
        largest = a;
    } else if (b >= a && b >= c) {
        largest = b;
    } else {
        largest = c;
    }

    console.log("The largest given integer is:", largest);
}

// Example usage:
findLargestInteger(10, 25, 145);
findLargestInteger(42, 17, 42);
findLargestInteger(-5, -2, -10);
findLargestInteger(1000, 10000, 1000000);
